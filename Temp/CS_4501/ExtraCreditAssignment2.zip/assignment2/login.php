<html>
<head>
<title>Enter your song </title>
</head>
<body>
<?php

session_start();
error_reporting(E_ERROR | E_WARNING | E_PARSE);

//openfile
$filename = "users.txt";
$fp = fopen($filename, "r");

//parse file
$content = fread($fp, filesize($filename));
$lines = explode("\n", $content);
fclose($fp);
$i=0;

//grab user info
foreach($lines as $val) {
  $temp_array=explode("#", $val);
   $usernames[$i]= $temp_array[0];
   $hashtable[$temp_array[0]]=$temp_array[1];
  $i=$i+1;
}
$username = $_POST['username'];
$_SESSION["username"] = $username;

$password = $_POST['password'];

//set remember me
if(isset($_POST['rememberme'])){
  $_SESSION["rememberme"] = true;
}
else{
  $_SESSION["rememberme"]= false;
}
$foundUser = false;


foreach($usernames as $val){


if($val==$username){
  $foundUser=true;

  //matched
  if($hashtable[$username]==$password){
    //set cookie
    if($_SESSION["rememberme"]){
      setcookie("current_user",$username, strtotime("tomorrow"));
    }
    //set session username
    $_SESSION["username"]= $username;
    header('Location: quizhomepage.php');
    exit;
  }
  else{
    echo "wrong password <br />";
  }
}
}
if($foundUser==false){
  echo "this user does not exist <br />";
}


/*
//parse file
$content = fread($fp, filesize($filename));
$lines = explode("\n", $content);
fclose($fp);

//variables
$curr = each($_GET);
$whichOutput = false;
$songName = rtrim($curr["value"]);
$output = "$songName has been added";
$output2 = "$songName has been previously sent";

//loop thorugh and compare
foreach($lines as $val) {
  if($songName==$val){
    $whichOutput = true;
  }
}

///Applications/XAMPP/xamppfiles/htdocs/CS_4501/assignment2/tile.txt
//correct output & append if needed
if($whichOutput){
echo  $output2;
}
else{
  file_put_contents($filename,$songName,FILE_APPEND);
  file_put_contents($filename,"\n",FILE_APPEND);
  echo  $output;

}
*/
  ?>
</body>
</html>
